import "./App.css";
import List from "./List";

function App() {
  return (
    <>
      <List />
    </>
  );
}

export default App;
