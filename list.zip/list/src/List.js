import React, { useState } from "react";
function TodoList() {
  const [next, setNext] = useState("");
  const [listdata, setlistdata] = useState([]);
  const handleNext = (event) => {
    setNext(event.target.value);
  };
  function addData() {
    setlistdata((listdata) => {
      const updatedList = [...listdata, next];
      setNext("");
      return updatedList;
    });
  }
  return (
    <>
      <div className="container">
        <h2>TODO LIST</h2>
        <input
          type="text"
          placeholder="Add"
          value={next}
          onChange={handleNext}
        />
        <button onClick={addData}>Add</button>
        <h3>Below is List :</h3>
        {listdata !== [] &&
          listdata.map((data, i) => {
            return (
              <>
                <div key={i}>
                  <p className="listdata">{data}</p>
                </div>
              </>
            );
          })}
      </div>
    </>
  );
}
export default TodoList;
